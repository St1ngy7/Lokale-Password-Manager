import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from cryptography.exceptions import InvalidTag
from vault import Vault, generate

class VaultTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'test.ltv'
        self.vault = Vault(self.path)
        self.vault.create('Eine lange Test-Passphrase!')
        self.rows = [dict(id='1', title='Privater Titel', user='user@example.test', password='GEHEIM-12345', url='example.test', notes='ÄÖÜ')]
        self.vault.save(self.rows)

    def test_roundtrip_and_no_plaintext(self):
        raw = self.path.read_bytes()
        for key in ('title', 'user', 'password', 'notes'):
            self.assertNotIn(self.rows[0][key].encode(), raw)
        self.assertEqual(Vault(self.path).unlock('Eine lange Test-Passphrase!'), self.rows)

    def test_wrong_password_and_tampering(self):
        with self.assertRaises(InvalidTag):
            Vault(self.path).unlock('falsches Passwort')
        raw = bytearray(self.path.read_bytes())
        raw[-1] ^= 1
        self.path.write_bytes(raw)
        with self.assertRaises(InvalidTag):
            Vault(self.path).unlock('Eine lange Test-Passphrase!')

    def test_nonce_changes_and_locked_save(self):
        before = self.path.read_bytes()
        self.vault.save(self.rows)
        self.assertNotEqual(before, self.path.read_bytes())
        self.vault.lock()
        with self.assertRaises(ValueError):
            self.vault.save([])

    def test_failed_write_preserves_old_file(self):
        before = self.path.read_bytes()
        with patch('vault.os.replace', side_effect=OSError('Disk error')):
            with self.assertRaises(OSError):
                self.vault.save([])
        self.assertEqual(before, self.path.read_bytes())
        self.assertEqual(list(self.path.parent.iterdir()), [self.path])

    def test_conflicting_edit(self):
        self.path.write_bytes(b'external change')
        with self.assertRaises(ValueError):
            self.vault.save([])

    def test_restore_retains_previous_and_uses_backup_password(self):
        source = Vault(Path(self.temp.name) / 'backup.ltv')
        source.create('Backup password!')
        previous = self.path.read_bytes()
        safety = self.vault.restore(source)
        self.assertEqual(safety.read_bytes(), previous)
        self.assertEqual(Vault(self.path).unlock('Backup password!'), [])
        self.assertEqual(Vault(safety).unlock('Eine lange Test-Passphrase!'), self.rows)

    def test_restore_write_failure_keeps_current(self):
        source = Vault(Path(self.temp.name) / 'backup.ltv')
        source.create('Backup password!')
        previous = self.path.read_bytes()
        with patch('vault.os.replace', side_effect=OSError('Disk error')):
            with self.assertRaises(OSError):
                self.vault.restore(source)
        self.assertEqual(self.path.read_bytes(), previous)
        self.assertEqual(self.vault.original, previous)

    def test_restore_rejects_unverified_backup(self):
        previous = self.path.read_bytes()
        with self.assertRaises(ValueError):
            self.vault.restore(Vault(Path(self.temp.name) / 'unknown.ltv'))
        self.assertEqual(self.path.read_bytes(), previous)

    def test_generator(self):
        values = {generate() for _ in range(100)}
        self.assertEqual(len(values), 100)
        self.assertTrue(all(len(value) == 24 for value in values))

    def test_master_password_minimum(self):
        path = Path(self.temp.name) / 'minimum.ltv'
        vault = Vault(path)
        with self.assertRaises(ValueError):
            vault.create('123456')
        self.assertFalse(path.exists())
        vault.create('1234567')
        self.assertEqual(Vault(path).unlock('1234567'), [])

class InterfaceTests(unittest.TestCase):
    def test_editor_copy_and_lock(self):
        import tkinter as tk
        from app import App
        with tempfile.TemporaryDirectory() as directory:
            root = tk.Tk()
            root.withdraw()
            app = App(root, directory)
            try:
                app.vault.create('Eine lange Test-Passphrase!')
                app.show_main()
                app.entries = [dict(id='1', title='Test', user='user', password='secret', url='', notes='')]
                app.vault.save(app.entries)
                app.refresh()
                app.table.selection_set('1')
                app.copy()
                self.assertEqual(root.clipboard_get(), 'secret')
                app.clear_clipboard()
                self.assertIsNone(app.copied)
                app.edit(False)
                root.update_idletasks()
                self.assertIsNotNone(app.editor)
                app.last_active -= 301
                app.tick()
                self.assertIsNone(app.vault.key)
                self.assertEqual(app.entries, [])
                self.assertIsNone(app.editor)
            finally:
                app.close()

if __name__ == '__main__':
    unittest.main()
