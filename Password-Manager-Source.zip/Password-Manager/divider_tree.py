"""Subtle one-pixel separators for a ttk table."""
import tkinter as tk
from tkinter import ttk

class DividerTree(ttk.Treeview):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self._lines = []
        self._pending = None
        self._line_color = '#30394a'
        self.bind('<Configure>', self.redraw_later, add='+')
        self.bind('<ButtonRelease-1>', self.redraw_later, add='+')
        self.bind('<B1-Motion>', self.redraw_later, add='+')
        self.bind('<<ThemeChanged>>', self.redraw_later, add='+')

    def set_line_color(self, color):
        self._line_color = color
        self.redraw_later()

    def redraw_later(self, event=None):
        if self._pending is None:
            self._pending = self.after_idle(self._redraw)

    def _redraw(self):
        self._pending = None
        width, height = self.winfo_width(), self.winfo_height()
        geometry = []
        rows = set()
        # Inspect only visible rows, even for very large vaults.
        for y in range(0, height, 8):
            row = self.identify_row(y)
            if row:
                rows.add(row)
        for row in rows:
            box = self.bbox(row)
            if box:
                x, y, w, h = box
                if 0 < y + h <= height:
                    geometry.append((0, y + h - 1, width, 1))
        header_bottom = next((y for y in range(height) if self.identify_region(5, y) not in ('heading', 'separator', 'nothing')), None)
        if header_bottom is not None:
            geometry.append((0, header_bottom - 1, width, 1))
        x = 0
        for column in self['columns'][:-1]:
            x += self.column(column, 'width')
            if x < width:
                geometry.append((x - 1, 8, 1, max(0, height - 16)))
        while len(self._lines) < len(geometry):
            line = tk.Frame(self, borderwidth=0, highlightthickness=0, takefocus=False)
            line.bind('<Button-1>', self._forward_click)
            self._lines.append(line)
        for line, (x, y, w, h) in zip(self._lines, geometry):
            line.configure(background=self._line_color)
            line.place(x=x, y=y, width=w, height=h)
            line.lift()
        for line in self._lines[len(geometry):]:
            line.place_forget()

    def _forward_click(self, event):
        self.event_generate('<Button-1>', x=event.x_root-self.winfo_rootx(), y=event.y_root-self.winfo_rooty())

    def destroy(self):
        if self._pending is not None:
            self.after_cancel(self._pending)
            self._pending = None
        super().destroy()
