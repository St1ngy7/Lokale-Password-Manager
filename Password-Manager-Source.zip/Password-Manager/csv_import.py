"""CSV parsing and mapping; never writes plaintext files."""
import csv
import io
import uuid
from pathlib import Path

FIELDS = ('title', 'user', 'password', 'url', 'notes')
ALIASES = {
    'title': ('title', 'titel', 'name'),
    'user': ('username', 'user', 'benutzername', 'email', 'e-mail', 'login_username'),
    'password': ('password', 'passwort', 'login_password'),
    'url': ('url', 'website', 'webseite', 'login_uri', 'hostname'),
    'notes': ('notes', 'note', 'notizen', 'kommentar', 'extra'),
}

def read_csv(path):
    with Path(path).open('rb') as stream:
        raw = stream.read(10 * 1024 * 1024 + 1)
    if len(raw) > 10 * 1024 * 1024:
        raise ValueError('Die CSV-Datei darf maximal 10 MB groß sein.')
    try:
        text = raw.decode('utf-16' if raw.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')
    except UnicodeDecodeError:
        text = raw.decode('cp1252')
    try:
        dialect = csv.Sniffer().sniff(text[:65536], delimiters=',;\t')
    except csv.Error:
        dialect = csv.excel
    try:
        reader = csv.reader(io.StringIO(text, newline=''), dialect, strict=True)
        headers = next(reader, [])
        if not headers or any(not h.strip() for h in headers):
            raise ValueError('Eine Kopfzeile mit Spaltennamen ist erforderlich.')
        rows = []
        for row in reader:
            if not row or not any(value.strip() for value in row):
                continue
            if len(row) != len(headers):
                raise ValueError(f'Abweichende Spaltenanzahl bei CSV-Zeile {reader.line_num}.')
            rows.append(row)
        if not rows:
            raise ValueError('Die CSV-Datei enthält keine Einträge.')
        return headers, rows
    except csv.Error as exc:
        raise ValueError('Die CSV-Datei ist nicht korrekt formatiert.') from exc

def suggest_mapping(headers):
    normalized = [h.strip().casefold() for h in headers]
    return {key: next((normalized.index(alias) for alias in ALIASES[key] if alias in normalized), None) for key in FIELDS}

def map_rows(rows, mapping, existing):
    if mapping.get('password') is None:
        raise ValueError('Bitte die Passwort-Spalte zuordnen.')
    if mapping.get('title') is None and mapping.get('url') is None:
        raise ValueError('Bitte mindestens Titel oder Website zuordnen.')
    seen = {tuple(row[key] for key in FIELDS) for row in existing}
    result, duplicates = [], 0
    for number, row in enumerate(rows, start=2):
        item = {key: row[mapping[key]] if mapping.get(key) is not None else '' for key in FIELDS}
        if not item['title'].strip():
            item['title'] = item['url'].strip() or item['user'].strip() or f'Importierter Eintrag {number - 1}'
        signature = tuple(item[key] for key in FIELDS)
        if signature in seen:
            duplicates += 1
            continue
        seen.add(signature)
        result.append(dict(id=str(uuid.uuid4()), **item))
    return result, duplicates
