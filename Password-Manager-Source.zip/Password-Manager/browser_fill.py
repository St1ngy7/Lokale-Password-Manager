"""Windows-only, extension-free companion. No clipboard or browser storage access."""
import ctypes as C
from ctypes import wintypes as W
import os
import queue
import threading
import tkinter as tk
from tkinter import ttk, messagebox

BROWSERS = {'chrome.exe', 'msedge.exe', 'firefox.exe', 'brave.exe', 'opera.exe', 'vivaldi.exe'}

class KEYBDINPUT(C.Structure):
    _fields_ = [('wVk', W.WORD), ('wScan', W.WORD), ('dwFlags', W.DWORD), ('time', W.DWORD), ('dwExtraInfo', C.c_size_t)]

class MOUSEINPUT(C.Structure):
    _fields_ = [('dx', W.LONG), ('dy', W.LONG), ('mouseData', W.DWORD), ('dwFlags', W.DWORD), ('time', W.DWORD), ('dwExtraInfo', C.c_size_t)]

class INPUTUNION(C.Union):
    _fields_ = [('ki', KEYBDINPUT), ('mi', MOUSEINPUT)]

class INPUT(C.Structure):
    _anonymous_ = ('u',)
    _fields_ = [('type', W.DWORD), ('u', INPUTUNION)]

def unicode_inputs(text):
    if any(ord(char) < 32 or ord(char) == 127 for char in text):
        raise ValueError('Dieses Feld enthält Steuerzeichen und kann nicht automatisch eingefügt werden.')
    if len(text) > 4096:
        raise ValueError('Dieses Feld ist zu lang zum automatischen Einfügen.')
    raw = text.encode('utf-16-le')
    events = []
    for offset in range(0, len(raw), 2):
        unit = int.from_bytes(raw[offset:offset+2], 'little')
        for flags in (4, 6):  # KEYEVENTF_UNICODE, then KEYEVENTF_KEYUP
            event = INPUT(type=1)
            event.ki = KEYBDINPUT(0, unit, flags, 0, 0)
            events.append(event)
    return (INPUT * len(events))(*events)

class Windows:
    def __init__(self):
        self.user = C.WinDLL('user32', use_last_error=True)
        self.kernel = C.WinDLL('kernel32', use_last_error=True)
        signatures = [
            (self.user.GetForegroundWindow, [], W.HWND),
            (self.user.GetWindowThreadProcessId, [W.HWND, C.POINTER(W.DWORD)], W.DWORD),
            (self.user.GetWindowTextW, [W.HWND, W.LPWSTR, C.c_int], C.c_int),
            (self.user.SetForegroundWindow, [W.HWND], W.BOOL),
            (self.user.ShowWindow, [W.HWND, C.c_int], W.BOOL),
            (self.user.GetAsyncKeyState, [C.c_int], C.c_short),
            (self.user.SendInput, [W.UINT, C.POINTER(INPUT), C.c_int], W.UINT),
            (self.user.RegisterHotKey, [W.HWND, C.c_int, W.UINT, W.UINT], W.BOOL),
            (self.user.UnregisterHotKey, [W.HWND, C.c_int], W.BOOL),
            (self.user.PeekMessageW, [C.POINTER(W.MSG), W.HWND, W.UINT, W.UINT, W.UINT], W.BOOL),
            (self.kernel.OpenProcess, [W.DWORD, W.BOOL, W.DWORD], W.HANDLE),
            (self.kernel.QueryFullProcessImageNameW, [W.HANDLE, W.DWORD, W.LPWSTR, C.POINTER(W.DWORD)], W.BOOL),
            (self.kernel.CloseHandle, [W.HANDLE], W.BOOL),
        ]
        for function, args, result in signatures:
            function.argtypes, function.restype = args, result

    def browser(self, hwnd=None):
        hwnd = hwnd or self.user.GetForegroundWindow()
        pid = W.DWORD()
        self.user.GetWindowThreadProcessId(hwnd, C.byref(pid))
        handle = self.kernel.OpenProcess(0x1000, False, pid.value)
        if not handle:
            return None
        try:
            path, length = C.create_unicode_buffer(32768), W.DWORD(32768)
            if not self.kernel.QueryFullProcessImageNameW(handle, 0, path, C.byref(length)):
                return None
            if os.path.basename(path.value).lower() not in BROWSERS:
                return None
            title = C.create_unicode_buffer(2048)
            self.user.GetWindowTextW(hwnd, title, len(title))
            return hwnd, pid.value, title.value
        finally:
            self.kernel.CloseHandle(handle)

    def send(self, target, text):
        if self.user.GetForegroundWindow() != target[0] or self.browser(target[0]) != target:
            raise ValueError('Browser oder Tab hat gewechselt. Bitte das gewünschte Feld erneut auswählen.')
        if any(self.user.GetAsyncKeyState(key) & 0x8000 for key in (0x10, 0x11, 0x12, 0x5b, 0x5c)):
            raise ValueError('Bitte Umschalt-, Strg-, Alt- und Windows-Tasten loslassen.')
        events = unicode_inputs(text)
        if events and self.user.SendInput(len(events), events, C.sizeof(INPUT)) != len(events):
            raise ValueError('Windows hat die Eingabe blockiert oder nur teilweise ausgeführt. Bitte das Feld prüfen.')

class BrowserFill:
    def __init__(self, app, api=None):
        self.app = app
        self.api = api or Windows()
        self.panel = None
        self.target = None
        self.selected_id = None
        self.expanded = False
        self.pending = None
        self.stopped = threading.Event()
        self.events = queue.Queue()
        self.hotkey_ok = None
        self.worker = threading.Thread(target=self.hotkeys, daemon=True)
        self.worker.start()
        self.timer = app.root.after(300, self.poll)

    def hotkeys(self):
        user = self.api.user
        self.hotkey_ok = bool(user.RegisterHotKey(None, 1, 0x4003, ord('L')))
        try:
            while not self.stopped.wait(0.05):
                msg = W.MSG()
                while user.PeekMessageW(C.byref(msg), None, 0x312, 0x312, 1):
                    target = self.api.browser()
                    if target:
                        self.events.put(target)
        finally:
            if self.hotkey_ok:
                user.UnregisterHotKey(None, 1)

    def hide(self):
        if self.pending is not None:
            self.app.root.after_cancel(self.pending)
            self.pending = None
        if self.panel is not None:
            self.panel.destroy()
        self.panel = None
        self.target = None
        self.expanded = False

    def poll(self):
        try:
            if self.app.vault.key is None or self.app.editor is not None:
                self.hide()
                while not self.events.empty():
                    self.events.get_nowait()
            elif self.pending is None:
                target = self.api.browser()
                hotkey = None
                while not self.events.empty():
                    hotkey = self.events.get_nowait()
                if hotkey and target == hotkey:
                    self.target = target
                    self.show(True)
                    self.app.activity()
                elif target:
                    if self.target != target:
                        self.hide()
                        self.target = target
                    if self.panel is None or not self.panel.winfo_viewable():
                        self.show(False)
                elif self.panel is not None:
                    pid = W.DWORD()
                    self.api.user.GetWindowThreadProcessId(self.api.user.GetForegroundWindow(), C.byref(pid))
                    if pid.value != os.getpid():
                        self.hide()
        finally:
            if not self.stopped.is_set():
                self.timer = self.app.root.after(300, self.poll)

    def show(self, expanded=False):
        if self.panel is None:
            self.panel = tk.Toplevel(self.app.root)
            self.panel.withdraw()
            self.panel.title('Password Manager · Browserhilfe')
            self.panel.attributes('-topmost', True)
            self.panel.resizable(False, False)
            self.panel.protocol('WM_DELETE_WINDOW', lambda: self.show(False))
        win = self.panel
        for child in win.winfo_children():
            child.destroy()
        self.expanded = expanded
        win.configure(background=self.app.background)
        frame = ttk.Frame(win, padding=12)
        frame.pack(fill='both', expand=True)
        if not expanded:
            ttk.Button(frame, text='Password Manager · Zugang auswählen', command=lambda: self.show(True)).pack()
            width, height = 360, 88
        else:
            ttk.Label(frame, text='1. Im Browser das gewünschte Eingabefeld anklicken.\n2. Hier einen Zugang wählen und das passende Feld einfügen.', wraplength=460).pack(anchor='w')
            ttk.Label(frame, text='Website selbst prüfen: Die Browserhilfe erkennt keine URL.', wraplength=460).pack(anchor='w', pady=8)
            query = tk.StringVar(win)
            ttk.Entry(frame, textvariable=query).pack(fill='x')
            table = ttk.Treeview(frame, columns=('title', 'user'), show='headings', height=6, selectmode='browse')
            table.heading('title', text='Titel / Website')
            table.heading('user', text='Benutzername')
            table.column('title', width=260)
            table.column('user', width=180)
            table.pack(fill='both', expand=True, pady=8)
            def refresh(*_):
                table.delete(*table.get_children())
                for row in self.app.entries:
                    if query.get().casefold() in ' '.join(row[k] for k in ('title', 'url', 'user')).casefold():
                        table.insert('', 'end', iid=row['id'], values=(row['title'] + ' · ' + row['url'], row['user']))
                if self.selected_id and table.exists(self.selected_id):
                    table.selection_set(self.selected_id)
            query.trace_add('write', refresh)
            refresh()
            def choose(field):
                selection = table.selection()
                if selection:
                    self.selected_id = selection[0]
                    self.fill(field)
            bar = ttk.Frame(frame)
            bar.pack(fill='x')
            ttk.Button(bar, text='Benutzername einfügen', command=lambda: choose('user')).pack(side='left')
            ttk.Button(bar, text='Passwort einfügen', command=lambda: choose('password')).pack(side='right')
            ttk.Label(frame, text='Strg + Alt + L: Backup' if self.hotkey_ok else 'Backup-Tastenkombination nicht verfügbar.').pack(anchor='w', pady=(8, 0))
            width, height = 540, 590
        x = max(0, win.winfo_screenwidth() - width - 28)
        y = max(0, win.winfo_screenheight() - height - 85)
        win.geometry(f'{width}x{height}+{x}+{y}')
        win.update_idletasks()
        # Show without stealing keyboard focus from the browser's input field.
        win.deiconify()
        if self.target:
            self.api.user.SetForegroundWindow(self.target[0])

    def fill(self, field):
        target = self.target
        entry_id = self.selected_id
        if self.app.vault.key is None or not target:
            return
        self.app.activity()
        self.panel.withdraw()
        self.api.user.SetForegroundWindow(target[0])
        def deliver():
            self.pending = None
            if self.app.vault.key is None:
                return
            row = next((row for row in self.app.entries if row['id'] == entry_id), None)
            if row is None:
                return
            try:
                self.api.send(target, row[field])
            except ValueError as exc:
                messagebox.showerror('Browser-Eingabe', str(exc), parent=self.app.root)
            self.hide()
        self.pending = self.app.root.after(250, deliver)

    def close(self):
        self.stopped.set()
        self.app.root.after_cancel(self.timer)
        self.hide()
        self.worker.join(timeout=1)
