"""Build a standalone Windows executable using paths relative to this project."""
import os
from pathlib import Path
import subprocess
import sys

def main():
    if os.name != 'nt':
        raise SystemExit('Bitte den EXE-Build unter Windows ausführen.')
    root = Path(__file__).resolve().parent
    subprocess.run([
        sys.executable, '-m', 'PyInstaller', '--noconfirm', '--onefile', '--windowed',
        '--name', 'Password Manager',
        '--icon', str(root / 'password-manager.ico'),
        '--version-file', str(root / 'version_info.txt'),
        '--add-data', str(root / 'password-manager.ico') + ';.',
        '--paths', str(root),
        '--distpath', str(root / 'dist'),
        '--workpath', str(root / 'build'),
        '--specpath', str(root / 'build'),
        str(root / 'exe_entry.py'),
    ], cwd=root, check=True)

if __name__ == '__main__':
    main()
