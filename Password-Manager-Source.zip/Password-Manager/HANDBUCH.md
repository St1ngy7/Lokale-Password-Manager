# Password Manager

Lokaler Passwortmanager für Windows mit deutscher Oberfläche. Zum Starten die bereitgestellte `Password Manager.exe` doppelklicken. Die EXE enthält die Python-Laufzeit und alle notwendigen Abhängigkeiten; eine Installation oder Internetverbindung ist nicht erforderlich. Vor dem Start eine bereits laufende ältere Version schließen. Der vorhandene Tresor wird am gleichen Speicherort weiterverwendet.

Für Entwicklung aus dem Quellcode siehe die Start- und Build-Anleitung in README.md.

Beim ersten Start ein Master-Passwort mit mindestens 7 Zeichen festlegen. Eine lange, zufällige Passphrase verwenden. Es gibt kein Zurücksetzen oder Wiederherstellen des Master-Passworts.

## Funktionen

- Start im Dark Mode; über „Light Mode“ / „Dark Mode“ auf dem Anmeldebildschirm und im Tresor umschalten. Die Auswahl gilt bis zum Beenden der Anwendung.
- Einträge erstellen, bearbeiten, löschen und durchsuchen
- Alle Einträge über „Alle Passwörter löschen“ in der Seitenleiste entfernen. Erst die Eingabe von `LÖSCHEN` bestätigt den Vorgang. Das Master-Passwort und bestehende Backup-Dateien bleiben erhalten; es wird dabei kein neues Backup angelegt.
- Zufällige Passwörter mit 24 Zeichen generieren
- Passwortanzeige optional; Kopieren mit Leerung der aktuellen Zwischenablage nach 20 Sekunden
- Automatische Sperre nach 5 Minuten ohne Tastatur- oder Maus-Klick-Aktivität in der Anwendung; ungespeicherte Änderungen werden dabei verworfen
- Verschlüsselte Backups über „Backup speichern“
- CSV-Import über „CSV importieren“: Datei auswählen, Spaltenzuordnung und Anzahl prüfen, dann „Jetzt importieren“. Unterstützt Komma, Semikolon und Tabulator sowie UTF-8, UTF-16 mit BOM und Windows-1252 (maximal 10 MB). Eine Kopfzeile ist erforderlich. Gängige deutsche und englische Spaltennamen werden vorgeschlagen; andere können manuell zugeordnet werden. Passwort sowie Titel oder Website müssen zugeordnet sein. Identische Einträge werden übersprungen, bestehende Einträge nicht überschrieben. Die CSV-Quelldatei bleibt unverändert und unverschlüsselt; importierte Daten werden im Tresor verschlüsselt gespeichert.

## Browserhilfe ohne Erweiterung

Bei entsperrtem Tresor erscheint unten rechts eine schwebende Schaltfläche, wenn Chrome, Edge, Firefox, Brave, Opera oder Vivaldi im Vordergrund ist. Die Anwendung muss geöffnet bleiben; sie darf minimiert werden.

1. Im Browser das gewünschte Benutzername- oder Passwortfeld anklicken.
2. „Password Manager · Zugang auswählen“ anklicken und einen Eintrag auswählen. Eine Suche ist vorhanden.
3. „Benutzername einfügen“ oder „Passwort einfügen“ anklicken. Der Browser erhält wieder den Fokus und das gewählte Feld wird als Tastatureingabe eingefügt. Vorhandener Feldinhalt wird nicht automatisch gelöscht.
4. Für das andere Feld den Vorgang wiederholen. Die Auswahl des Zugangs bleibt für die Sitzung erhalten. Absenden erfolgt manuell.

Als Backup öffnet **Strg + Alt + L** die Auswahl im aktiven unterstützten Browser. Ist diese Kombination bereits belegt, zeigt die Browserhilfe an, dass sie nicht verfügbar ist. Bei gesperrtem Tresor bleibt die Browserhilfe aus.

Die Browserhilfe liest keine URL oder Formularfelder aus und prüft keine Domainzugehörigkeit. Deshalb Website und aktives Eingabefeld vor jedem Einfügen selbst prüfen. Sie erscheint auch auf Seiten ohne Anmeldung. Fenstertitel und Browserprozess werden vor der Eingabe erneut geprüft; das ersetzt keine URL-Prüfung. Keine Zwischenablage, kein automatisches Absenden, kein Lesen des Browser-Passwortspeichers. Manche Webseiten oder als Administrator gestartete Browser können die Eingabe blockieren. Windows-Systemdialoge und Webseiten verwenden weiterhin ihr eigenes Design.

## Speicherort und Wiederherstellung

Der Tresor liegt unter `%LOCALAPPDATA%\LokalTresor\tresor.ltv`, normalerweise außerhalb von OneDrive. Titel, Benutzernamen, Passwörter, Websites und Notizen werden gemeinsam verschlüsselt. Backups bleiben ebenfalls verschlüsselt. Regelmäßig ein Backup auf einem separaten lokalen Datenträger speichern.

Wiederherstellung: „Backup laden“ in der Seitenleiste oder auf dem Anmeldebildschirm anklicken, eine `.ltv`-Datei auswählen und deren Master-Passwort eingeben. Nach erfolgreicher Prüfung die Wiederherstellung bestätigen. Das Backup ersetzt den aktuellen Tresor; Einträge werden nicht zusammengeführt. Vorher wird der bisherige Tresor automatisch als `Vor-Wiederherstellung-….ltv` im Tresorordner gesichert. Danach gilt das Master-Passwort des geladenen Backups. Auch die automatische Sicherung kann über „Backup laden“ wiederhergestellt werden.

## Technische Grenzen

AES-256-GCM mit zufälliger 96-Bit-Nonce pro Speicherung, scrypt mit zufälligem 128-Bit-Salt und N=131072, r=8, p=1. Speicherung über verschlüsselte temporäre Datei und atomaren Austausch. Eine Prozesssperre verhindert zwei gleichzeitige Instanzen. Keine Telemetrie, Cloud oder automatischen Updates. Die optionale Browser-Eingabe erfolgt lokal über Windows-Tastaturereignisse.

Dies ist eine selbst entwickelte erste Version ohne unabhängiges Sicherheitsaudit. Schadsoftware auf dem Rechner kann entsperrte Daten auslesen. Python garantiert keine vollständige Löschung sensibler Daten aus dem Arbeitsspeicher. Windows-Zwischenablageverlauf, Synchronisierung und andere Zwischenablageprogramme können Kopien behalten: Bei sensiblen Daten diese Funktionen deaktivieren oder auf Kopieren verzichten. Der automatische Timer entfernt nur den aktuellen, unveränderten Zwischenablageinhalt.

Kryptografie-Referenz: https://cryptography.io/en/stable/hazmat/primitives/aead/

Windows-APIs: https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput und https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-registerhotkey
