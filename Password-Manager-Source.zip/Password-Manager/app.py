import os
import sys
import time
import uuid
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, filedialog, simpledialog
from cryptography.exceptions import InvalidTag
from vault import Vault, generate
from csv_import import read_csv, suggest_mapping, map_rows
from divider_tree import DividerTree

class App:
    def __init__(self, root, data_dir=None):
        self.root = root
        self.directory = Path(data_dir or Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'LokalTresor')
        self.directory.mkdir(parents=True, exist_ok=True)
        # OS-held lock automatically releases after crashes, preventing concurrent writers.
        self.guard = open(self.directory / 'instance.lock', 'a+b')
        if os.name == 'nt':
            import msvcrt
            self.guard.seek(0)
            self.guard.write(b'0')
            self.guard.flush()
            self.guard.seek(0)
            try:
                msvcrt.locking(self.guard.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                self.guard.close()
                raise RuntimeError('LokalTresor ist bereits geöffnet.')
        self.vault = Vault(self.directory / 'tresor.ltv')
        self.entries = []
        self.editor = None
        self.copied = None
        self.last_active = time.monotonic()
        root.title('Password Manager')
        icon_path = Path(getattr(sys, '_MEIPASS', Path(__file__).parent)) / 'password-manager.ico'
        if icon_path.exists():
            root.iconbitmap(default=str(icon_path))
        if os.name == 'nt':
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('PasswordManager.Desktop')
        root.geometry('1180x760')
        root.minsize(1000, 700)
        style = ttk.Style(root)
        style.theme_use('clam')
        style.configure('.', font=('Segoe UI', 11))
        style.configure('TButton', padding=(12, 8))
        style.configure('Title.TLabel', font=('Segoe UI Variable Display', 28, 'bold'))
        style.configure('Treeview', rowheight=56, borderwidth=0, font=('Segoe UI', 11))
        self.style = style
        self.dark_mode = True
        self.theme_label = tk.StringVar(root)
        self.apply_theme()
        root.bind_all('<KeyPress>', self.activity)
        root.bind_all('<ButtonPress>', self.activity)
        root.protocol('WM_DELETE_WINDOW', self.close)
        self.show_login()
        self.browser_fill = None
        if os.name == 'nt' and data_dir is None:
            from browser_fill import BrowserFill
            self.browser_fill = BrowserFill(self)
        root.after(1000, self.tick)

    def activity(self, event=None):
        self.last_active = time.monotonic()

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.apply_theme()

    def apply_theme(self):
        if self.dark_mode:
            bg, field, fg, border, hover = '#101319', '#1a202b', '#f0f3fa', '#2b3444', '#293347'
        else:
            bg, field, fg, border, hover = '#f3f5fa', '#ffffff', '#182235', '#dce2ed', '#e5eaf5'
        accent = '#6264ed'
        muted = '#98a5bc' if self.dark_mode else '#61708a'
        sidebar = '#151923' if self.dark_mode else '#e9edf6'
        self.background = bg
        self.theme_label.set('Light Mode' if self.dark_mode else 'Dark Mode')
        self.root.configure(background=bg)
        if self.editor is not None:
            self.editor.configure(background=bg)
        self.style.configure('.', background=bg, foreground=fg, bordercolor=border,
                             lightcolor=border, darkcolor=border, troughcolor=bg,
                             selectbackground=accent, selectforeground='#ffffff')
        self.style.configure('TEntry', fieldbackground=field, foreground=fg,
                             insertcolor=fg, padding=12, borderwidth=1)
        self.style.map('TEntry', fieldbackground=[('readonly', bg)],
                       bordercolor=[('focus', accent)])
        self.style.configure('TButton', background=field, borderwidth=0, padding=(16, 12), relief='flat', font=('Segoe UI', 10, 'bold'))
        self.style.map('TButton', background=[('pressed', accent), ('active', hover)],
                       foreground=[('pressed', '#ffffff'), ('active', fg)])
        self.style.configure('TCheckbutton', indicatorbackground=field)
        self.style.map('TCheckbutton', background=[('active', bg)],
                       indicatorbackground=[('selected', accent), ('active', hover)])
        self.style.configure('Treeview', background=field, fieldbackground=field, foreground=fg)
        self.style.map('Treeview', background=[('selected', accent)],
                       foreground=[('selected', '#ffffff')])
        self.style.configure('Treeview.Heading', background=bg, foreground=fg)
        self.style.map('Treeview.Heading', background=[('active', hover)])
        self.style.configure('Vertical.TScrollbar', background=field, arrowcolor=fg)
        self.style.map('Vertical.TScrollbar', background=[('active', hover), ('pressed', accent)])

        self.style.configure('Sidebar.TFrame', background=sidebar)
        self.style.configure('Sidebar.TLabel', background=sidebar, foreground=muted, font=('Segoe UI', 10))
        self.style.configure('Brand.TLabel', background=sidebar, foreground=fg, font=('Segoe UI', 16, 'bold'))
        self.style.configure('Nav.TButton', background=sidebar, foreground=muted, anchor='w', padding=(16, 14))
        self.style.map('Nav.TButton', background=[('active', hover)], foreground=[('active', fg)])
        self.style.configure('Primary.TButton', background=accent, foreground='#ffffff', padding=(20, 13))
        self.style.map('Primary.TButton', background=[('active', '#7779fa'), ('pressed', '#5052cb')], foreground=[('active', '#ffffff')])
        self.style.configure('Danger.TButton', foreground='#ef8896')
        self.style.configure('Muted.TLabel', foreground=muted, font=('Segoe UI', 10))
        self.style.configure('Eyebrow.TLabel', foreground='#989aff', font=('Segoe UI', 10, 'bold'))
        self.style.configure('Badge.TLabel', background=sidebar, foreground='#73d9b0', padding=(12, 7), font=('Segoe UI', 9, 'bold'))
        self.style.configure('Treeview.Heading', font=('Segoe UI', 10, 'bold'), foreground=muted, padding=(12, 14), relief='flat', borderwidth=0)
        self.style.layout('Treeview', [('Treeview.treearea', {'sticky': 'nswe'})])
        if hasattr(self, 'table') and self.table.winfo_exists():
            self.table.set_line_color('#30394a' if self.dark_mode else '#dce2ed')
        if os.name == 'nt':
            import ctypes
            handle = ctypes.windll.user32.GetParent(self.root.winfo_id())
            value = ctypes.c_int(int(self.dark_mode))
            ctypes.windll.dwmapi.DwmSetWindowAttribute(ctypes.c_void_p(handle), 20, ctypes.byref(value), 4)

    def theme_button(self, parent):
        return ttk.Button(parent, textvariable=self.theme_label, command=self.toggle_theme)

    def clear(self):
        if getattr(self, 'browser_fill', None):
            self.browser_fill.hide()
        for child in self.root.winfo_children():
            child.destroy()

    def show_login(self):
        self.clear()
        self.theme_button(self.root).pack(anchor='ne', padx=24, pady=(16, 0))
        box = ttk.Frame(self.root, padding=40)
        box.pack(expand=True)
        ttk.Label(box, text='DEIN DIGITALER TRESOR', style='Eyebrow.TLabel').pack(anchor='w', pady=(0, 14))
        ttk.Label(box, text='Password Manager', style='Title.TLabel').pack(anchor='w')
        exists = self.vault.path.exists()
        ttk.Label(box, text='Ein sicherer Platz für deine Zugänge. Nur auf deinem Gerät.', style='Muted.TLabel').pack(anchor='w', pady=(8, 28))
        ttk.Label(box, text='Master-Passwort' if exists else 'Master-Passwort festlegen (mindestens 7 Zeichen)').pack(anchor='w')
        password = ttk.Entry(box, show='•', width=45)
        password.pack(fill='x', pady=8)
        confirm = None
        if not exists:
            ttk.Label(box, text='Master-Passwort wiederholen').pack(anchor='w')
            confirm = ttk.Entry(box, show='•', width=45)
            confirm.pack(fill='x', pady=8)
            ttk.Label(box, text='Merke dir das Master-Passwort. Es gibt keine Wiederherstellung.').pack(anchor='w', pady=8)
        def unlock(event=None):
            value = password.get()
            try:
                if exists:
                    entries = self.vault.unlock(value)
                else:
                    if value != confirm.get():
                        raise ValueError('Die Passwörter stimmen nicht überein.')
                    self.vault.create(value)
                    entries = []
                password.delete(0, 'end')
                if confirm:
                    confirm.delete(0, 'end')
                self.entries = entries
                self.activity()
                self.show_main()
            except InvalidTag:
                messagebox.showerror('Öffnen fehlgeschlagen', 'Master-Passwort falsch oder Tresor beschädigt.', parent=self.root)
            except (ValueError, OSError) as exc:
                messagebox.showerror('Öffnen fehlgeschlagen', str(exc), parent=self.root)
        ttk.Button(box, text='Tresor entsperren  →' if exists else 'Tresor erstellen  →', style='Primary.TButton', command=unlock).pack(fill='x', pady=16)
        ttk.Button(box, text='Backup laden', command=self.restore_backup).pack(fill='x', pady=(0, 8))
        password.bind('<Return>', unlock)
        if confirm:
            confirm.bind('<Return>', unlock)
        ttk.Label(box, text='●  Lokal gespeichert     ·     Verschlüsselt     ·     Ohne Cloud', style='Muted.TLabel').pack(anchor='w', pady=12)
        password.focus_set()

    def show_main(self):
        self.clear()
        sidebar = ttk.Frame(self.root, style='Sidebar.TFrame', width=240, padding=(22, 30))
        sidebar.pack(side='left', fill='y')
        sidebar.pack_propagate(False)
        ttk.Label(sidebar, text='Password\nManager', style='Brand.TLabel').pack(anchor='w', pady=(0, 8))
        ttk.Label(sidebar, text='DEIN PRIVATER TRESOR', style='Sidebar.TLabel').pack(anchor='w', pady=(0, 38))
        ttk.Label(sidebar, text='BIBLIOTHEK', style='Sidebar.TLabel').pack(anchor='w', pady=(0, 10))
        ttk.Button(sidebar, text='Alle Passwörter', style='Primary.TButton', command=lambda: self.query.set('')).pack(fill='x')
        self.count_label = ttk.Label(sidebar, text='', style='Sidebar.TLabel')
        self.count_label.pack(anchor='w', padx=16, pady=(8, 32))
        ttk.Label(sidebar, text='VERWALTEN', style='Sidebar.TLabel').pack(anchor='w', pady=(0, 10))
        ttk.Button(sidebar, text='↓   CSV importieren', style='Nav.TButton', command=self.import_csv).pack(fill='x')
        ttk.Button(sidebar, text='↗   Backup speichern', style='Nav.TButton', command=self.backup).pack(fill='x')
        ttk.Button(sidebar, text='↙   Backup laden', style='Nav.TButton', command=self.restore_backup).pack(fill='x')
        ttk.Button(sidebar, text='Alle Passwörter löschen', style='Danger.TButton', command=self.delete_all).pack(fill='x', pady=(20, 0))
        ttk.Button(sidebar, text='Tresor sperren', command=self.lock).pack(side='bottom', fill='x', pady=(10, 0))
        self.theme_button(sidebar).pack(side='bottom', fill='x')
        ttk.Label(sidebar, text='●  Nur auf diesem Gerät', style='Sidebar.TLabel').pack(side='bottom', pady=24)
        frame = ttk.Frame(self.root, padding=(34, 32))
        frame.pack(side='left', fill='both', expand=True)
        top = ttk.Frame(frame)
        top.pack(fill='x')
        ttk.Label(top, text='DEINE BIBLIOTHEK', style='Eyebrow.TLabel').pack(side='left')
        ttk.Label(top, text='●  Tresor entsperrt', style='Badge.TLabel').pack(side='right')
        heading = ttk.Frame(frame)
        heading.pack(fill='x', pady=(18, 6))
        ttk.Label(heading, text='Alle Passwörter', style='Title.TLabel').pack(side='left')
        ttk.Button(heading, text='+  Neuer Eintrag', style='Primary.TButton', command=lambda: self.edit(True)).pack(side='right')
        ttk.Label(frame, text='Deine Zugänge. Übersichtlich und immer griffbereit.', style='Muted.TLabel').pack(anchor='w', pady=(0, 26))
        self.query = tk.StringVar()
        ttk.Label(frame, text='SUCHEN', style='Muted.TLabel').pack(anchor='w', pady=(0, 7))
        search = ttk.Entry(frame, textvariable=self.query)
        search.pack(fill='x')
        ttk.Label(frame, text='Titel, Benutzername oder Website', style='Muted.TLabel').pack(anchor='w', pady=(6, 18))
        self.query.trace_add('write', lambda *_: self.refresh())
        table_frame = ttk.Frame(frame)
        table_frame.pack(fill='both', expand=True)
        self.table = DividerTree(table_frame, columns=('title', 'user', 'url'), show='headings', selectmode='browse')
        self.table.set_line_color('#30394a' if self.dark_mode else '#dce2ed')
        for key, label in [('title', 'ZUGANG'), ('user', 'BENUTZERNAME'), ('url', 'WEBSITE')]:
            self.table.heading(key, text=label, anchor='w')
            self.table.column(key, width=190, minwidth=100, anchor='w')
        scrollbar = ttk.Scrollbar(table_frame, orient='vertical', command=self.table.yview)
        def on_scroll(first, last):
            scrollbar.set(first, last)
            self.table.redraw_later()
        self.table.configure(yscrollcommand=on_scroll)
        self.table.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        self.empty_label = ttk.Label(table_frame, text='', style='Muted.TLabel', anchor='center', justify='center')
        self.table.bind('<Double-1>', lambda _: self.edit(False))
        bar = ttk.Frame(frame)
        bar.pack(fill='x', pady=(18, 0))
        ttk.Button(bar, text='Passwort kopieren', command=self.copy).pack(side='left', padx=(0, 8))
        ttk.Button(bar, text='Bearbeiten', command=lambda: self.edit(False)).pack(side='left')
        ttk.Button(bar, text='Löschen', style='Danger.TButton', command=self.delete).pack(side='right')
        self.status = ttk.Label(frame, text='', style='Muted.TLabel', wraplength=650)
        self.status.pack(anchor='w', pady=(18, 0))
        self.refresh()

    def refresh(self):
        selected = self.table.selection()
        self.table.delete(*self.table.get_children())
        query = self.query.get().casefold()
        for row in sorted(self.entries, key=lambda e: e['title'].casefold()):
            if query in ' '.join(row[k] for k in ('title', 'user', 'url')).casefold():
                self.table.insert('', 'end', iid=row['id'], values=tuple(row[k] for k in ('title', 'user', 'url')))
        if selected and self.table.exists(selected[0]):
            self.table.selection_set(selected[0])
        self.count_label.configure(text=f'{len(self.entries)} gespeicherte Zugänge')
        if self.table.get_children():
            self.empty_label.place_forget()
        else:
            self.empty_label.configure(text='Keine passenden Zugänge gefunden.\nVersuche einen anderen Suchbegriff.' if self.entries else 'Dein Tresor ist bereit.\nErstelle deinen ersten Eintrag oder importiere eine CSV-Datei.')
            self.empty_label.place(relx=0.5, rely=0.5, anchor='center')
        self.status.configure(text=f'{len(self.table.get_children())} Einträge angezeigt  ·  Automatische Sperre nach 5 Minuten')
        self.table.redraw_later()

    def selected(self):
        selected = self.table.selection()
        return next((row for row in self.entries if selected and row['id'] == selected[0]), None)

    def commit(self, entries):
        try:
            self.vault.save(entries)
        except (OSError, ValueError) as exc:
            messagebox.showerror('Speichern fehlgeschlagen', str(exc), parent=self.editor or self.root)
            return False
        self.entries = entries
        self.refresh()
        return True

    def edit(self, new):
        row = {'id': str(uuid.uuid4()), 'title': '', 'user': '', 'password': '', 'url': '', 'notes': ''} if new else self.selected()
        if row is None:
            return
        win = self.editor = tk.Toplevel(self.root)
        win.title('Neuer Eintrag' if new else 'Eintrag bearbeiten')
        win.geometry('600x700')
        win.configure(background=self.background)
        win.transient(self.root)
        win.grab_set()
        frame = ttk.Frame(win, padding=24)
        frame.pack(fill='both', expand=True)
        fields = {}
        for key, label in [('title', 'Titel *'), ('user', 'Benutzername / E-Mail'), ('password', 'Passwort'), ('url', 'Website'), ('notes', 'Notizen')]:
            ttk.Label(frame, text=label).pack(anchor='w', pady=(8, 3))
            field = ttk.Entry(frame, show='•' if key == 'password' else '')
            field.insert(0, row[key])
            field.pack(fill='x')
            fields[key] = field
            if key == 'password':
                controls = ttk.Frame(frame)
                controls.pack(fill='x', pady=8)
                def make_password():
                    fields['password'].delete(0, 'end')
                    fields['password'].insert(0, generate())
                ttk.Button(controls, text='24 Zeichen generieren', command=make_password).pack(side='left')
                visible = tk.BooleanVar(value=False)
                ttk.Checkbutton(controls, text='Anzeigen', variable=visible, command=lambda: fields['password'].configure(show='' if visible.get() else '•')).pack(side='left', padx=12)
        def dismiss():
            for field in fields.values():
                field.delete(0, 'end')
            win.destroy()
            self.editor = None
        def save():
            updated = {'id': row['id'], **{key: field.get() for key, field in fields.items()}}
            if not updated['title'].strip():
                messagebox.showerror('Titel fehlt', 'Bitte einen Titel eingeben.', parent=win)
                return
            entries = [updated if item['id'] == row['id'] else item for item in self.entries]
            if new:
                entries.append(updated)
            if self.commit(entries):
                dismiss()
        ttk.Button(frame, text='Speichern', style='Primary.TButton', command=save).pack(side='right', pady=20)
        ttk.Button(frame, text='Abbrechen', command=dismiss).pack(side='right', padx=8, pady=20)
        win.protocol('WM_DELETE_WINDOW', dismiss)
        fields['title'].focus_set()

    def delete(self):
        row = self.selected()
        if row and messagebox.askyesno('Eintrag löschen', f'„{row["title"]}“ endgültig löschen?', parent=self.root):
            self.commit([item for item in self.entries if item['id'] != row['id']])

    def delete_all(self):
        if not self.entries:
            messagebox.showinfo('Tresor ist leer', 'Es sind keine Einträge zum Löschen vorhanden.', parent=self.root)
            return
        answer = simpledialog.askstring('Alle Passwörter löschen',
                    f'Alle {len(self.entries)} Einträge mit Benutzernamen, Passwörtern und Notizen löschen?\n\n'
                    'Das kann nur mit einem vorhandenen Backup rückgängig gemacht werden. '
                    'Bestehende Backup-Dateien bleiben erhalten.\n\n'
                    'Zur Bestätigung LÖSCHEN eingeben:', parent=self.root)
        if answer != 'LÖSCHEN' or self.vault.key is None:
            return
        if self.commit([]):
            self.clear_clipboard()
            if getattr(self, 'browser_fill', None):
                self.browser_fill.hide()
                self.browser_fill.selected_id = None
            self.status.configure(text='Alle Einträge wurden gelöscht. Dein Tresor ist jetzt leer.')

    def copy(self):
        row = self.selected()
        if row:
            self.clear_clipboard()
            self.root.clipboard_clear()
            self.root.clipboard_append(row['password'])
            self.copied = row['password']
            self.clipboard_deadline = time.monotonic() + 20
            self.status.configure(text='Passwort kopiert. Zwischenablage wird nach 20 Sekunden geleert.')

    def clear_clipboard(self):
        if self.copied is not None:
            try:
                if self.root.clipboard_get() == self.copied:
                    self.root.clipboard_clear()
            except tk.TclError:
                pass
        self.copied = None

    def import_csv(self):
        source = filedialog.askopenfilename(parent=self.root, title='CSV-Datei importieren',
                                          filetypes=[('CSV-Dateien', '*.csv'), ('Alle Dateien', '*.*')])
        if not source or self.vault.key is None:
            return
        try:
            headers, rows = read_csv(source)
        except (OSError, ValueError, UnicodeError) as exc:
            messagebox.showerror('Import fehlgeschlagen', str(exc), parent=self.root)
            return
        win = self.editor = tk.Toplevel(self.root)
        win.title('CSV importieren · Spalten zuordnen')
        win.geometry('680x650')
        win.configure(background=self.background)
        win.transient(self.root)
        win.grab_set()
        frame = ttk.Frame(win, padding=24)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text=f'{len(rows)} CSV-Einträge gefunden', style='Title.TLabel').pack(anchor='w')
        ttk.Label(frame, text='Spalten prüfen. Bestehende Einträge bleiben erhalten.').pack(anchor='w', pady=12)
        choices = ['— Nicht übernehmen —'] + [f'{i+1}: {name}' for i, name in enumerate(headers)]
        suggested = suggest_mapping(headers)
        selectors = {}
        self.style.configure('TCombobox', fieldbackground=self.background, foreground=self.style.lookup('TLabel', 'foreground'))
        self.style.map('TCombobox', fieldbackground=[('readonly', self.background)],
                       foreground=[('readonly', self.style.lookup('TLabel', 'foreground'))])
        for key, label in [('title', 'Titel'), ('user', 'Benutzername'), ('password', 'Passwort *'), ('url', 'Website'), ('notes', 'Notizen')]:
            ttk.Label(frame, text=label).pack(anchor='w', pady=(6, 2))
            selector = ttk.Combobox(frame, values=choices, state='readonly')
            selector.current(0 if suggested[key] is None else suggested[key] + 1)
            selector.pack(fill='x')
            selectors[key] = selector
        summary = ttk.Label(frame, text='', wraplength=570)
        summary.pack(anchor='w', pady=16)
        def prepare():
            mapping = {key: widget.current() - 1 if widget.current() > 0 else None for key, widget in selectors.items()}
            return map_rows(rows, mapping, self.entries)
        def preview(event=None):
            try:
                entries, duplicates = prepare()
                summary.configure(text=f'Vorschau: {len(entries)} neue Einträge; {duplicates} identische Duplikate werden übersprungen.')
            except ValueError as exc:
                summary.configure(text=str(exc))
        for selector in selectors.values():
            selector.bind('<<ComboboxSelected>>', preview)
        def dismiss():
            rows.clear()
            win.destroy()
            self.editor = None
        def accept():
            if self.vault.key is None:
                return
            try:
                entries, duplicates = prepare()
            except ValueError as exc:
                messagebox.showerror('Zuordnung prüfen', str(exc), parent=win)
                return
            if entries and not self.commit(self.entries + entries):
                return
            self.status.configure(text=f'CSV-Import: {len(entries)} hinzugefügt, {duplicates} Duplikate übersprungen.')
            dismiss()
        buttons = ttk.Frame(frame)
        buttons.pack(fill='x')
        ttk.Button(buttons, text='Jetzt importieren', style='Primary.TButton', command=accept).pack(side='right')
        ttk.Button(buttons, text='Abbrechen', command=dismiss).pack(side='right', padx=8)
        win.protocol('WM_DELETE_WINDOW', dismiss)
        preview()

    def restore_backup(self):
        source = filedialog.askopenfilename(parent=self.root, title='Verschlüsseltes Backup laden',
                                          filetypes=[('Verschlüsselter Tresor', '*.ltv')])
        if not source:
            return
        password = simpledialog.askstring('Backup entsperren', 'Master-Passwort dieses Backups:', show='•', parent=self.root)
        if password is None:
            return
        candidate = Vault(source)
        try:
            entries = candidate.unlock(password)
            password = None
            if not messagebox.askyesno('Backup wiederherstellen',
                    f'Dieses Backup enthält {len(entries)} Einträge.\n\n'
                    'Der aktuelle Tresor wird ersetzt, nicht zusammengeführt. '
                    'Vorher wird automatisch eine verschlüsselte Sicherung des aktuellen Tresors angelegt.\n\n'
                    'Danach gilt das Master-Passwort des Backups. Jetzt wiederherstellen?', parent=self.root):
                return
            safety = self.vault.restore(candidate)
            self.clear_clipboard()
            self.entries = entries
            self.activity()
            self.show_main()
            messagebox.showinfo('Backup geladen', f'{len(entries)} Einträge wiederhergestellt.' +
                                (f'\n\nBisheriger Tresor gesichert unter:\n{safety}' if safety else ''), parent=self.root)
        except InvalidTag:
            messagebox.showerror('Backup nicht geladen', 'Master-Passwort falsch oder Backup beschädigt. Der aktuelle Tresor bleibt erhalten.', parent=self.root)
        except (OSError, ValueError) as exc:
            messagebox.showerror('Backup nicht geladen', str(exc), parent=self.root)
        finally:
            password = None
            candidate.lock()

    def backup(self):
        target = filedialog.asksaveasfilename(parent=self.root, title='Verschlüsseltes Backup speichern', defaultextension='.ltv', initialfile='LokalTresor-Backup.ltv', filetypes=[('Verschlüsselter Tresor', '*.ltv')])
        if target:
            try:
                destination = Path(target)
                if destination.resolve() == self.vault.path.resolve():
                    raise ValueError('Bitte einen anderen Speicherort auswählen.')
                destination.write_bytes(self.vault.original)
                self.status.configure(text='Verschlüsseltes Backup gespeichert.')
            except (OSError, ValueError) as exc:
                messagebox.showerror('Backup fehlgeschlagen', str(exc), parent=self.root)

    def lock(self):
        self.clear_clipboard()
        self.vault.lock()
        self.entries = []
        self.editor = None
        self.show_login()

    def tick(self):
        if self.copied is not None and time.monotonic() >= self.clipboard_deadline:
            self.clear_clipboard()
        if self.vault.key is not None and time.monotonic() - self.last_active >= 300:
            self.lock()
        self.root.after(1000, self.tick)

    def close(self):
        if getattr(self, 'browser_fill', None):
            self.browser_fill.close()
        self.clear_clipboard()
        self.vault.lock()
        self.entries = []
        self.guard.close()
        self.root.destroy()

if __name__ == '__main__':
    root = tk.Tk()
    try:
        App(root)
    except Exception as exc:
        messagebox.showerror('LokalTresor', str(exc), parent=root)
        root.destroy()
    else:
        root.mainloop()
