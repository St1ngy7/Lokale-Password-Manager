import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from csv_import import read_csv, suggest_mapping, map_rows

class CsvTests(unittest.TestCase):
    def test_formats_mapping_and_duplicates(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.csv'
            for encoding in ('utf-8-sig', 'utf-16', 'cp1252'):
                path.write_text('name;username;password;url;notes\nÄpfel;user;" pass;word ";https://example.test;"Zeile 1\nZeile 2"\n', encoding=encoding, newline='')
                headers, rows = read_csv(path)
                entries, duplicates = map_rows(rows, suggest_mapping(headers), [])
                self.assertEqual(entries[0]['password'], ' pass;word ')
                self.assertEqual(entries[0]['title'], 'Äpfel')
                self.assertEqual(entries[0]['notes'], 'Zeile 1\nZeile 2')
                self.assertEqual(map_rows(rows, suggest_mapping(headers), entries), ([], 1))
                self.assertEqual(duplicates, 0)

    def test_bad_columns_and_missing_mapping(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.csv'
            path.write_text('title,password\nTest,secret,extra\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                read_csv(path)
        with self.assertRaises(ValueError):
            map_rows([['value']], {'title': 0}, [])

    def test_import_dialog_saves_encrypted_and_cancel_preserves(self):
        import tkinter as tk
        from tkinter import ttk
        from app import App
        from vault import Vault
        def buttons(widget):
            result = []
            for child in widget.winfo_children():
                if isinstance(child, ttk.Button):
                    result.append(child)
                result.extend(buttons(child))
            return result
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.csv'
            path.write_text('name,username,password,url\nTest,user,private-password,https://example.test\n', encoding='utf-8')
            root = tk.Tk()
            root.withdraw()
            app = App(root, directory)
            try:
                app.vault.create('1234567')
                app.show_main()
                with patch('app.filedialog.askopenfilename', return_value=str(path)):
                    app.import_csv()
                    root.update_idletasks()
                    next(b for b in buttons(app.editor) if b.cget('text') == 'Abbrechen').invoke()
                    self.assertEqual(app.entries, [])
                    app.import_csv()
                    next(b for b in buttons(app.editor) if b.cget('text') == 'Jetzt importieren').invoke()
                    self.assertEqual(len(app.entries), 1)
                    self.assertNotIn(b'private-password', app.vault.path.read_bytes())
                    self.assertEqual(Vault(app.vault.path).unlock('1234567')[0]['password'], 'private-password')
                    app.import_csv()
                    next(b for b in buttons(app.editor) if b.cget('text') == 'Jetzt importieren').invoke()
                    self.assertEqual(len(app.entries), 1)
                    app.import_csv()
                    app.lock()
                    self.assertIsNone(app.editor)
                    self.assertIsNone(app.vault.key)
            finally:
                app.close()

if __name__ == '__main__':
    unittest.main()
