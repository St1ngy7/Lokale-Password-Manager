"""Packaging entry point and isolated frozen-runtime smoke test."""
import sys
import json
import tempfile
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
from app import App
from vault import Vault
from browser_fill import Windows

if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--self-test':
        report = Path(sys.argv[2])
        try:
            with tempfile.TemporaryDirectory(dir=report.parent) as directory:
                root = tk.Tk()
                root.withdraw()
                app = App(root, directory)
                try:
                    app.vault.create('Test1234567!')
                    app.show_main()
                    app.vault.save([])
                    assert Vault(app.vault.path).unlock('Test1234567!') == []
                    app.toggle_theme()
                    root.update_idletasks()
                    Windows().browser()
                    app.lock()
                finally:
                    app.close()
            report.write_text(json.dumps({'ok': True, 'frozen': bool(getattr(sys, 'frozen', False)), 'checks': ['tkinter', 'AES-GCM', 'scrypt', 'vault roundtrip', 'theme', 'Windows APIs']}))
        except Exception as exc:
            report.write_text(json.dumps({'ok': False, 'error': str(exc)}))
            sys.exit(1)
    else:
        root = tk.Tk()
        try:
            App(root)
        except Exception as exc:
            messagebox.showerror('LokalTresor', str(exc), parent=root)
            root.destroy()
        else:
            root.mainloop()
