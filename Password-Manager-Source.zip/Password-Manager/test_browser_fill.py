import ctypes
import unittest
from unittest.mock import Mock, patch
from browser_fill import Windows, INPUT, unicode_inputs

class BrowserTests(unittest.TestCase):
    def test_unicode_input_layout(self):
        self.assertEqual(ctypes.sizeof(INPUT), 40 if ctypes.sizeof(ctypes.c_void_p) == 8 else 28)
        events = unicode_inputs('aÄ🔑')
        self.assertEqual(len(events), 8)
        self.assertEqual(events[0].ki.wScan, ord('a'))
        self.assertEqual(events[1].ki.dwFlags, 6)
        self.assertEqual(events[4].ki.wScan, 0xd83d)

    def test_control_characters_rejected(self):
        for value in ('secret\n', 'secret\t', 'secret\r', 'secret\0'):
            with self.assertRaises(ValueError):
                unicode_inputs(value)

    def api(self):
        api = Windows.__new__(Windows)
        api.user = Mock()
        api.user.GetForegroundWindow.return_value = 12
        api.user.GetAsyncKeyState.return_value = 0
        api.browser = Mock(return_value=(12, 5, 'Example'))
        return api

    def test_target_and_modifier_checks(self):
        api = self.api()
        target = (12, 5, 'Example')
        api.user.GetForegroundWindow.return_value = 99
        with self.assertRaises(ValueError):
            api.send(target, 'secret')
        api.user.SendInput.assert_not_called()
        api.user.GetForegroundWindow.return_value = 12
        api.browser.return_value = (12, 5, 'Other tab')
        with self.assertRaises(ValueError):
            api.send(target, 'secret')
        api.user.SendInput.assert_not_called()
        api.browser.return_value = target
        api.user.GetAsyncKeyState.return_value = 0x8000
        with self.assertRaises(ValueError):
            api.send(target, 'secret')
        api.user.SendInput.assert_not_called()

    def test_send_and_partial_failure(self):
        api = self.api()
        api.user.SendInput.return_value = 12
        api.send((12, 5, 'Example'), 'secret')
        self.assertEqual(api.user.SendInput.call_args.args[0], 12)
        api.user.SendInput.return_value = 1
        with self.assertRaises(ValueError):
            api.send((12, 5, 'Example'), 'secret')

    def test_panel_and_lock_cancel_pending_input(self):
        import tkinter as tk
        import tempfile
        from app import App
        from browser_fill import BrowserFill
        with tempfile.TemporaryDirectory() as directory:
            root = tk.Tk()
            root.withdraw()
            app = App(root, directory)
            api = self.api()
            api.user.RegisterHotKey.return_value = False
            api.user.PeekMessageW.return_value = False
            try:
                app.vault.create('1234567')
                app.show_main()
                app.entries = [dict(id='1', title='Test', user='user', password='secret', url='https://example.test', notes='')]
                helper = app.browser_fill = BrowserFill(app, api=api)
                helper.target = (12, 5, 'Example')
                helper.show(True)
                root.update_idletasks()
                helper.selected_id = '1'
                helper.fill('password')
                self.assertIsNotNone(helper.pending)
                app.lock()
                self.assertIsNone(helper.pending)
                self.assertIsNone(helper.panel)
                api.user.SendInput.assert_not_called()
            finally:
                app.close()

if __name__ == '__main__':
    unittest.main()
