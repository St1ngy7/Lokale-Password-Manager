"""Local encrypted vault. No network or plaintext persistence."""
import json
import os
import secrets
import string
import tempfile
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = b'LOKALTRESOR\x01'

def derive(password, salt):
    return Scrypt(salt=salt, length=32, n=2**17, r=8, p=1).derive(password.encode('utf-8'))

def generate(length=24):
    groups = [string.ascii_lowercase, string.ascii_uppercase, string.digits, '!#$%&()*+,-.:;<=>?@[]^_{|}~']
    while True:
        result = ''.join(secrets.choice(''.join(groups)) for _ in range(length))
        if all(any(c in group for c in result) for group in groups):
            return result

class Vault:
    def __init__(self, path):
        self.path = Path(path)
        self.key = None
        self.salt = None
        self.original = None

    def create(self, password):
        if self.path.exists():
            raise FileExistsError('Dieser Tresor existiert bereits.')
        if len(password) < 7:
            raise ValueError('Bitte mindestens 7 Zeichen verwenden.')
        self.salt = secrets.token_bytes(16)
        self.key = derive(password, self.salt)
        self.save([])

    def unlock(self, password):
        raw = self.path.read_bytes()
        if len(raw) < len(MAGIC) + 44 or not raw.startswith(MAGIC):
            raise ValueError('Unbekanntes oder beschädigtes Tresorformat.')
        offset = len(MAGIC)
        salt = raw[offset:offset+16]
        nonce = raw[offset+16:offset+28]
        key = derive(password, salt)
        data = json.loads(AESGCM(key).decrypt(nonce, raw[offset+28:], MAGIC + salt))
        if not isinstance(data, list) or any(not isinstance(row, dict) or any(not isinstance(row.get(k), str) for k in ('title', 'user', 'password', 'url', 'notes', 'id')) for row in data):
            raise ValueError('Ungültige Tresordaten.')
        if any(not row['id'] for row in data) or len({row['id'] for row in data}) != len(data):
            raise ValueError('Ungültige oder doppelte Eintrags-IDs.')
        self.key, self.salt, self.original = key, salt, raw
        return data

    def save(self, entries):
        if self.key is None:
            raise ValueError('Tresor ist gesperrt.')
        current = self.path.read_bytes() if self.path.exists() else None
        if current != self.original:
            raise ValueError('Die Datei wurde extern verändert. Bitte neu öffnen.')
        nonce = secrets.token_bytes(12)
        raw = MAGIC + self.salt + nonce + AESGCM(self.key).encrypt(nonce, json.dumps(entries, ensure_ascii=False).encode('utf-8'), MAGIC + self.salt)
        fd, name = tempfile.mkstemp(prefix='.tresor-', dir=self.path.parent)
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(name, self.path)
            self.original = raw
        finally:
            if os.path.exists(name):
                os.unlink(name)

    def restore(self, verified_backup):
        """Install already authenticated bytes, retaining the previous encrypted file."""
        if verified_backup.key is None or verified_backup.original is None:
            raise ValueError('Das Backup muss zuerst entsperrt und geprüft werden.')
        if verified_backup.path.resolve() == self.path.resolve():
            raise ValueError('Bitte eine separate Backup-Datei auswählen.')
        previous = self.path.read_bytes() if self.path.exists() else None
        if self.key is not None and previous != self.original:
            raise ValueError('Der aktuelle Tresor wurde extern verändert. Bitte neu öffnen.')
        safety = None
        if previous is not None:
            safety = self.path.parent / ('Vor-Wiederherstellung-' + secrets.token_hex(8) + '.ltv')
            with safety.open('xb') as stream:
                stream.write(previous)
                stream.flush()
                os.fsync(stream.fileno())
        fd, name = tempfile.mkstemp(prefix='.restore-', dir=self.path.parent)
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(verified_backup.original)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(name, self.path)
        finally:
            if os.path.exists(name):
                os.unlink(name)
        self.key, self.salt, self.original = verified_backup.key, verified_backup.salt, verified_backup.original
        return safety

    def lock(self):
        self.key = self.salt = self.original = None
